-- 1
select year(s.from_date) as yr, round(avg(s.salary),2) as avg_salary
from employees.salaries s
group by year(s.from_date)
order by yr;

-- 2
select d.dept_name as dept,
       round(avg(s.salary),2) as avg_salary
from employees.dept_emp de
inner join employees.salaries s 
       on s.emp_no = de.emp_no
      and current_date between s.from_date and s.to_date
inner join employees.departments d 
       on d.dept_no = de.dept_no
where current_date between de.from_date and de.to_date
group by d.dept_name
order by dept;

-- 3
with years as (
    select distinct year(from_date) as yr
    from employees.salaries
)

select d.dept_name as dept,
       y.yr,
       round(avg(s.salary),2) as avg_salary
from years y
inner join employees.salaries s
        on y.yr between year(s.from_date) and year(s.to_date)
inner join employees.dept_emp de
        on de.emp_no = s.emp_no
       and y.yr between year(de.from_date) and year(de.to_date)
inner join employees.departments d
        on d.dept_no = de.dept_no
group by d.dept_name, y.yr
order by dept, y.yr;



-- 4
with years as (
    select distinct year(from_date) as yr
    from employees.dept_emp
)

select yr, dept_name, avg_salary
from (
    select y.yr,
           d.dept_name,
           round(avg(s.salary),2) as avg_salary,
           row_number() over (
               partition by y.yr
               order by count(distinct de.emp_no) desc
           ) as rn
    from years y
    join employees.dept_emp de
         on y.yr between year(de.from_date) and year(de.to_date)
    join employees.departments d
         on d.dept_no = de.dept_no
    join employees.salaries s
         on s.emp_no = de.emp_no
        and y.yr between year(s.from_date) and year(s.to_date)
    group by y.yr, d.dept_name
) t
where rn = 1
order by yr;


-- 5
select e.emp_no as manager_no,
       d.dept_name as dept,
       e.hire_date as hire_date,
       e.last_name as last_name
from employees.dept_manager dm
inner join employees.employees e 
        on e.emp_no = dm.emp_no
inner join employees.departments d 
        on d.dept_no = dm.dept_no
where current_date between dm.from_date and dm.to_date
  and dm.from_date = (
        select min(from_date)
        from employees.dept_manager
        where current_date between from_date and to_date
  );